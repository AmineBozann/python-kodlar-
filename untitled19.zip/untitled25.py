# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:12:02 2024

@author: AMİNE BOZAN
"""

# 1’den 10’a kadar sayıları yanlarına tek ve çift yazarak yazdır.
for i in range(0,11):
  if i%2==1:
    print(i,"Tek Sayıdır")
  else:
    print(i,"Çift sayıdır")