# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:10:54 2024

@author: AMİNE BOZAN
"""

# 1’den 10’a kadar sayıları yazdır
for i in range (1,11) :
  print(i, end='')