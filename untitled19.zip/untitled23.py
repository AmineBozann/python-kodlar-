# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:11:03 2024

@author: AMİNE BOZAN
"""

# 10’dan 1 e kadar sayıları yazdır
for i in range(10,0,-1):
  print(i)