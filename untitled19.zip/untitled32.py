# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:13:56 2024

@author: AMİNE BOZAN
"""

sayac=1
toplam=0

for i in range(1,100):
  toplam=toplam+sayac
  sayac=sayac+2

print("toplam:",toplam)
# 1+3+5+ ....... + 99