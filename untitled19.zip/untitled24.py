# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:11:14 2024

@author: AMİNE BOZAN
"""

# 1’den 10’a kadar tek sayıları yazdır.
for i in range(1,101):
  print(i)
for i in range(1,11):
  if i%3 and i%5==0:
    print(i)
