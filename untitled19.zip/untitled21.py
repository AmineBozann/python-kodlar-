# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:10:45 2024

@author: AMİNE BOZAN
"""

# Ekranan 5 defa Bilgisayar yazdırmak
for i in range (5):
  print("bilgisayar")