# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:09:06 2024

@author: AMİNE BOZAN
"""

sehir=""
while sehir!='ankara':
  sehir =input("türkiyenin başkentini giriniz:").lower()
  if sehir== "ankara":
    print("doğru bildiniz")
  else:
   print("bilemediniz")