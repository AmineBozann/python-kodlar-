# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:05:00 2024

@author: AMİNE BOZAN
"""

#Ekrana girilen bir sayının tek olup olmadığını girsin
sayı=int(input("sayıyı giriniz"))
if(sayı%2==0):
  print("sayınız çiftir")
else:
  print("sayınız tektir")