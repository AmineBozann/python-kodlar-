# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:07:54 2024

@author: AMİNE BOZAN
"""

# while
#1’den 100 e kadar sayıları yanyana yazdırın
a = 1
while a<101:
  print(a, end=' ')
  a +=1