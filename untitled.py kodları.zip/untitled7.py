# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:07:01 2024

@author: AMİNE BOZAN
"""

print('benim adım')
for i in range(5):
  print('Halil 5 defa ',str(i+1),'.')