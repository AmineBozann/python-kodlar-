# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:08:04 2024

@author: AMİNE BOZAN
"""

#20’den 1’e kadar yazıları yazdırın
i=50
while i>=1:
  print(i,end=' ')
  i-=1