# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:07:13 2024

@author: AMİNE BOZAN
"""

toplam = 0

for i in range(101):
  toplam+=i

print(toplam)