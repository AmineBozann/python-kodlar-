# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:08:27 2024

@author: AMİNE BOZAN
"""

#1’den 50’ye kadar tek sayıları yazdırın.
sayac = 0
while sayac != 50 :
  sayac = sayac +1
  if sayac%2 == 1 :
    print(sayac , end=' ')
