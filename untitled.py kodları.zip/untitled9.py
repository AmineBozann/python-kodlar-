# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:07:27 2024

@author: AMİNE BOZAN
"""

for i in range(5,16,3):
  print(i,end=' ') # yan yana yazmak için