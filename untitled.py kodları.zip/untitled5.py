# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:05:57 2024

@author: AMİNE BOZAN
"""

# while döngüsü
while True:
  isim = input('lütfen adınızı giriniz')
  if isim == 'ahmet':
    break
print('hoşgeldin ahmet')