# -*- coding: utf-8 -*-
"""
Created on Sun Jun 23 13:04:06 2024

@author: AMİNE BOZAN
"""

#yKlavyeden Yaşını girsin 25-35 aralığında ise
#at kulübüne katılabilirsiniz yazsın
yas=int(input("yasınızı giriniz"))
if 25<yas<35 :
  print("at klubüne katılabirisin")
else :
  print("at kulubüne katılamazsın")